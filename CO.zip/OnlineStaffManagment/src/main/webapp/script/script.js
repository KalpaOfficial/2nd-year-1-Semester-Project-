document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const togglePassword = document.getElementById('togglePassword');
    const errorMessage = document.getElementById('errorMessage');
    const loginButton = document.getElementById('loginButton');
    const buttonText = document.getElementById('buttonText');
    const loader = document.getElementById('loader');
    
    // Toggle password visibility
    togglePassword.addEventListener('click', function() {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        this.classList.toggle('fa-eye');
        this.classList.toggle('fa-eye-slash');
    });
    
    // Form validation and submission
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Reset error message
        errorMessage.style.display = 'none';
        
        // Get values
        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();
        
        // Validate inputs
        if (!username || !password) {
            showError('Please fill in both username and password');
            return;
        }
        
        // Show loading state
        buttonText.textContent = 'Logging in...';
        loader.style.display = 'block';
        loginButton.disabled = true;
        
        // Simulate form submission (replace with actual AJAX call if needed)
        setTimeout(() => {
            // Here you would typically make an AJAX call to your LoginServlet
            // For demonstration, we'll just submit the form
            this.submit();
            
            // In a real AJAX implementation, you would handle the response here
            // and either proceed on success or show error on failure
        }, 1500);
    });
    
    // Show error message
    function showError(message) {
        errorMessage.textContent = message;
        errorMessage.style.display = 'block';
        
        // Hide error after 5 seconds
        setTimeout(() => {
            errorMessage.style.display = 'none';
        }, 5000);
    }
    
    // Input field validation on blur
    usernameInput.addEventListener('blur', validateUsername);
    passwordInput.addEventListener('blur', validatePassword);
    
    function validateUsername() {
        const username = usernameInput.value.trim();
        if (!username) {
            usernameInput.style.borderColor = 'var(--error-color)';
            return false;
        }
        usernameInput.style.borderColor = 'var(--gray-color)';
        return true;
    }
    
    function validatePassword() {
        const password = passwordInput.value.trim();
        if (!password) {
            passwordInput.style.borderColor = 'var(--error-color)';
            return false;
        }
        passwordInput.style.borderColor = 'var(--gray-color)';
        return true;
    }
});