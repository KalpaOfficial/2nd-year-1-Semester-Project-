package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Complaint;
import service.ComplaintServices;



@WebServlet("/ComplaintUpdate")
public class ComplainUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Complaint complaint = new Complaint();
		
		int complaintId = Integer.parseInt(request.getParameter("complaint_id"));
		String employeeId = request.getParameter("employee_id");
		String message = request.getParameter("message");
		
		complaint.setComplaint_id(complaintId);
		complaint.setEmployee_id(employeeId);
		complaint.setMessage(message);
		
		ComplaintServices service = new ComplaintServices();
		
		service.ComplaintUpdate(complaint);
		
		RequestDispatcher dispatch = request.getRequestDispatcher("ComplaintView");
		
		dispatch.forward(request, response);
		
	}

}
