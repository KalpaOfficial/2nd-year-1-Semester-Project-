package servlet;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import model.leaves;
import service.leaveservices;

@WebServlet("/addleave")
public class addleave extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get form data
        String employeeId = request.getParameter("employeeId");


		// Set today's date
		String dateStr = request.getParameter("leaveDate"); // format: YYYY-MM-DD
		Date date = Date.valueOf(dateStr);

        String leaveType = request.getParameter("leaveType");

        // Create a leave object
        leaves lea = new leaves();
        lea.setEmployee_id(employeeId);
        lea.setLeave_date(date);
        lea.setLeave_type(leaveType);
        
        leaveservices service = new leaveservices();
        service.addleave(lea);  


        response.sendRedirect("userd.jsp");
    }
}
