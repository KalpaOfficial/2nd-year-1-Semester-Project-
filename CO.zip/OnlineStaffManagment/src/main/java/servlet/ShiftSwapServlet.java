// controller/ShiftSwapServlet.java
package servlet;

import model.ShiftSwapRequest;
import model.User;
import service.ShiftSwapService;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.Date;
import java.sql.Time;

@WebServlet("/ShiftSwapServlet")
public class ShiftSwapServlet extends HttpServlet {
    private ShiftSwapService swapService = new ShiftSwapService();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if ("approve".equals(action)) {
            int requestId = Integer.parseInt(request.getParameter("id"));
            swapService.approveRequest(requestId);
        } else if ("reject".equals(action)) {
            int requestId = Integer.parseInt(request.getParameter("id"));
            swapService.rejectRequest(requestId);
        }
        
        response.sendRedirect("admin_shiftswap.jsp");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        String employeeId = user.getEmployeeId();
        Date shiftDate = Date.valueOf(request.getParameter("shiftDate"));
        Time shiftStart = Time.valueOf(request.getParameter("shiftStart") + ":00");
        Time shiftEnd = Time.valueOf(request.getParameter("shiftEnd") + ":00");
        String reason = request.getParameter("reason");
        
        ShiftSwapRequest swapRequest = new ShiftSwapRequest(employeeId, shiftDate, shiftStart, shiftEnd, reason);
        
        if (swapService.createRequest(swapRequest)) {
            session.setAttribute("message", "Shift swap request submitted successfully");
        } else {
            session.setAttribute("error", "Failed to submit shift swap request");
        }
        
        response.sendRedirect("emp_viewshift.jsp");
    }
}