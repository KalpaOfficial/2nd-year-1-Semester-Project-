package servlet;

import model.User;
import service.UserService;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class SignupServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String employeeId = req.getParameter("employeeId");
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String role = req.getParameter("role");

        User user = new User();
        user.setEmployeeId(employeeId);
        user.setUsername(username);
        user.setPassword(password);
        user.setRole(role);

        boolean success = new UserService().registerUser(user);
        if (success) {
            resp.sendRedirect("login.jsp");
        } else {
            resp.getWriter().println("Signup failed. Employee ID or Username may already exist.");
        }
    }
}
