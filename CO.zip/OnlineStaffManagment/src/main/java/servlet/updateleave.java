package servlet;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.leaves;
import service.leaveservices;


@WebServlet("/updateleave")
public class updateleave extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		leaves lea = new leaves();
		   // Get form data
		String levid = request.getParameter("leaveid");
        String employeeId = request.getParameter("eid");


		// Set today's date
		String dateStr = request.getParameter("ldate"); // format: YYYY-MM-DD
		Date date = Date.valueOf(dateStr);

        String leaveType = request.getParameter("ltype");
        String status = request.getParameter("status");

        lea.setLeave_id(Integer.parseInt(levid));
        lea.setEmployee_id(employeeId);
        lea.setLeave_date(date);
        lea.setLeave_type(leaveType);
        lea.setStatus(status);
		
        
        
        leaveservices serv = new leaveservices();
        serv.update(lea);
        
        RequestDispatcher dis = request.getRequestDispatcher("userd.jsp");
        dis.forward(request, response);
		
	}

}
