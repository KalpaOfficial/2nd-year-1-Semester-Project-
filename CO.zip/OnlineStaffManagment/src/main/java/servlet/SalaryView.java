package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Complaint;
import model.Salary;
import service.SalaryServices;





@WebServlet("/SalaryView")
public class SalaryView extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
		    throws ServletException, IOException {
		    
		    try {
		        // 1. First try to get complaints from request (if coming from ComplaintView)
		        ArrayList<Complaint> complaints = (ArrayList<Complaint>) request.getAttribute("complaint");
		        
		        // 2. If not in request, try session
		        if(complaints == null || complaints.isEmpty()) {
		            complaints = (ArrayList<Complaint>) request.getSession().getAttribute("complaint");
		        }
		        
		        // 3. Process salary data
		        String employeeID = request.getParameter("employee_id");
		        int month = Integer.parseInt(request.getParameter("month"));
		        int year = Integer.parseInt(request.getParameter("year"));
		        
		        SalaryServices service = new SalaryServices();
		        ArrayList<Salary> salary = service.SalaryView(employeeID, month, year);
		        
		        // 4. Store ALL data in request
		        request.setAttribute("salary", salary);
		        request.setAttribute("complaint", complaints);
		        
		        // 5. Forward with all data
		        String destination = salary.isEmpty() ? "InvalidSalaryInfo.jsp" : "ValidSalaryInfo.jsp";
		        request.getRequestDispatcher(destination).forward(request, response);
		        
		    } catch (Exception e) {
		        // On error, preserve data and return to salary page
		        request.setAttribute("error", "Error: " + e.getMessage());
		        request.getRequestDispatcher("SalaryPage.jsp").forward(request, response);
		    }
		}

}
