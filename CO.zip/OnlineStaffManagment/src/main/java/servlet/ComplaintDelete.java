package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Complaint;
import service.ComplaintServices;



@WebServlet("/ComplaintDelete")
public class ComplaintDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    response.setContentType("application/json");
	    PrintWriter out = response.getWriter();
	    
	    try {
	        Complaint complaint = new Complaint();
	        int complaint_id = Integer.parseInt(request.getParameter("complaint_id"));
	        complaint.setComplaint_id(complaint_id);
	        
	        ComplaintServices service = new ComplaintServices();
	        boolean success = service.ComplaintDelete(complaint);
	        
	        if (success) {
	            response.setStatus(HttpServletResponse.SC_OK);
	            out.print("{\"status\":\"success\"}");
	        } else {
	            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	            out.print("{\"status\":\"error\",\"message\":\"Failed to delete complaint\"}");
	        }
	    } catch (Exception e) {
	        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	        out.print("{\"status\":\"error\",\"message\":\"" + e.getMessage() + "\"}");
	    } finally {
	        out.flush();
	    }
	}

}
