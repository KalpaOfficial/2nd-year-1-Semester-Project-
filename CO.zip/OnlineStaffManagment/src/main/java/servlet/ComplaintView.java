package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Complaint;
import service.ComplaintServices;




@WebServlet("/ComplaintView")
public class ComplaintView extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
		    throws ServletException, IOException {
		    
		    ComplaintServices service = new ComplaintServices();
		    String employee_id = request.getParameter("employee_id");
		    
		    ArrayList<Complaint> complaint = service.ComplaintView(employee_id);
		    
		    // Store in BOTH request and session
		    request.setAttribute("complaint", complaint);
		    request.getSession().setAttribute("complaint", complaint);
		    
		    RequestDispatcher dispatch = request.getRequestDispatcher("SalaryPage.jsp");
		    dispatch.forward(request, response);
		}

}
