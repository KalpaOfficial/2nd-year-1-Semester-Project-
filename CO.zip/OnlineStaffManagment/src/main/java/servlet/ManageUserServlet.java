package servlet;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.User;
import service.UserService;

@WebServlet("/ManageUserServlet")
public class ManageUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserService userService;
    
    @Override
    public void init() throws ServletException {
        super.init();
        this.userService = new UserService();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if ("delete".equals(action)) {
            deleteUser(request, response);
        } else {
            listUsers(request, response);
        }
    }

    private void deleteUser(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            
            if (userService.deleteUser(id)) {
                request.getSession().setAttribute("message", "User deleted successfully");
            } else {
                request.getSession().setAttribute("error", "Failed to delete user");
            }
        } catch (Exception e) {
            request.getSession().setAttribute("error", "Error deleting user: " + e.getMessage());
        }
        
        response.sendRedirect("ManageUserServlet");
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if ("delete".equals(action)) {
            deleteUser(request, response);
        } else {
            String id = request.getParameter("userId");
            if (id == null || id.isEmpty()) {
                addUser(request, response);
            } else {
                updateUser(request, response);
            }
        }
    }
    
    private void listUsers(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<User> users = userService.getAllUsers();
        request.setAttribute("users", users);
        request.getRequestDispatcher("manageUsers.jsp").forward(request, response);
    }
    
    private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        User user = userService.getUserById(id);
        request.setAttribute("user", user);
        request.getRequestDispatcher("editUser.jsp").forward(request, response);
    }
    
    private void addUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User user = new User();
        user.setEmployeeId(request.getParameter("employeeId"));
        user.setUsername(request.getParameter("username"));
        user.setPassword(request.getParameter("password"));
        user.setRole(request.getParameter("role"));
        
        if (userService.registerUser(user)) {
            response.sendRedirect("ManageUserServlet");
        } else {
            request.setAttribute("error", "Failed to add user");
            request.getRequestDispatcher("manageUsers.jsp").forward(request, response);
        }
    }
    
    private void updateUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User user = new User();
        user.setId(Integer.parseInt(request.getParameter("userId")));
        user.setEmployeeId(request.getParameter("employeeId"));
        user.setUsername(request.getParameter("username"));
        user.setRole(request.getParameter("role"));
        
        String password = request.getParameter("password");
        boolean success;
        
        if (password != null && !password.isEmpty()) {
            user.setPassword(password);
            success = userService.updateUserWithPassword(user);
        } else {
            success = userService.updateUserWithoutPassword(user);
        }
        
        if (success) {
            response.sendRedirect("ManageUserServlet");
        } else {
            request.setAttribute("error", "Failed to update user");
            request.getRequestDispatcher("manageUsers.jsp").forward(request, response);
        }
    }
    
    
}