package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Complaint;
import service.ComplaintServices;



@WebServlet("/ComplaintAdd")
public class ComplaintAdd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Complaint complaint = new Complaint();
		
		String employee_id = request.getParameter("employee_id");
		String message = request.getParameter("message");
		
		complaint.setEmployee_id(employee_id);
		complaint.setMessage(message);
		
		ComplaintServices service = new ComplaintServices();
		
		service.ComplaintAdd(complaint);
		
		RequestDispatcher dispatch = request.getRequestDispatcher("ComplaintView");
		
		dispatch.forward(request, response);
		
	}

}
