package servlet;

import model.Shift;
import model.User;
import service.ShiftService;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.Date;
import java.sql.Time;
import java.util.List;

@WebServlet("/ManageShiftServlet")
public class ManageShiftServlet extends HttpServlet {
    private ShiftService shiftService = new ShiftService();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null || !"admin".equals(user.getRole())) {
            response.sendRedirect("login.jsp");
            return;
        }

        String action = request.getParameter("action");
        
        if ("delete".equals(action)) {
            try {
                int shiftId = Integer.parseInt(request.getParameter("id"));
                boolean deleted = shiftService.deleteShift(shiftId);
                
                if (deleted) {
                    session.setAttribute("message", "Shift deleted successfully");
                } else {
                    session.setAttribute("error", "Failed to delete shift");
                }
            } catch (Exception e) {
                session.setAttribute("error", "Error deleting shift: " + e.getMessage());
            }
            response.sendRedirect("manageShifts.jsp");
            return;
        }

        List<Shift> shifts = shiftService.getAllShifts();
        request.setAttribute("shifts", shifts);
        request.getRequestDispatcher("manageShifts.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        
        try {
            String employeeId = request.getParameter("employeeId");
            Date shiftDate = Date.valueOf(request.getParameter("shiftDate"));
            Time shiftStart = Time.valueOf(request.getParameter("shiftStart") + ":00");
            Time shiftEnd = Time.valueOf(request.getParameter("shiftEnd") + ":00");
            
            Shift shift = new Shift(employeeId, shiftDate, shiftStart, shiftEnd);
            
            if (request.getParameter("shiftId") != null && !request.getParameter("shiftId").isEmpty()) {
                // Update existing shift
                shift.setId(Integer.parseInt(request.getParameter("shiftId")));
                boolean updated = shiftService.updateShift(shift);
                
                if (updated) {
                    session.setAttribute("message", "Shift updated successfully");
                } else {
                    session.setAttribute("error", "Failed to update shift");
                }
            } else {
                // Create new shift
                boolean assigned = shiftService.assignShift(shift);
                
                if (assigned) {
                    session.setAttribute("message", "Shift assigned successfully");
                } else {
                    session.setAttribute("error", "Failed to assign shift");
                }
            }
        } catch (Exception e) {
            session.setAttribute("error", "Error processing shift: " + e.getMessage());
        }
        
        response.sendRedirect("manageShifts.jsp");
    }
}