package service;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import model.leaves;
import util.DBUtil;

public class leaveservices {

	
	public void addleave(leaves lev) {
		
		try {
			
			String query = "INSERT INTO leaves (employee_id, leave_date, leave_type) " +
		               "VALUES('" + lev.getEmployee_id() + "', '" + lev.getLeave_date() + "', '" + lev.getLeave_type() + "')";
			Statement stat = DBUtil.getConnection().createStatement();
			stat.executeUpdate(query);
			
			
		} catch (Exception e) {
e.printStackTrace();		}
		
		
		
	}
	
	
	public ArrayList<leaves> getAllEmpLeaves(String employeeID) {
	    ArrayList<leaves> listlev = new ArrayList<>();

	    try {
	        String query = "SELECT * FROM leaves WHERE employee_id = '" + employeeID + "'";

	        Statement sta = DBUtil.getConnection().createStatement();
	        ResultSet rs = sta.executeQuery(query);

	        while (rs.next()) {
	            leaves lev = new leaves();

	            lev.setLeave_id(rs.getInt("leave_id"));
	            lev.setEmployee_id(rs.getString("employee_id"));
	            lev.setLeave_date(rs.getDate("leave_date")); 
	            lev.setLeave_type(rs.getString("leave_type"));

	            listlev.add(lev);
	        }

	        return listlev;

	    } catch (Exception e) {
	        e.printStackTrace();
	        return null;
	    }
	}

	
	public ArrayList<leaves> getAllEmpLeaves1() {
	    ArrayList<leaves> listlev = new ArrayList<>();

	    try {
	        String query = "SELECT * FROM leaves ";

	        Statement sta = DBUtil.getConnection().createStatement();
	        ResultSet rs = sta.executeQuery(query);

	        while (rs.next()) {
	            leaves lev = new leaves();

	            lev.setLeave_id(rs.getInt("leave_id"));
	            lev.setEmployee_id(rs.getString("employee_id"));
	            lev.setLeave_date(rs.getDate("leave_date")); 
	            lev.setLeave_type(rs.getString("leave_type"));

	            listlev.add(lev);
	        }

	        return listlev;

	    } catch (Exception e) {
	        e.printStackTrace();
	        return null;
	    }
	}
	
	
	public leaves singleLeav(leaves lev) {
		
		try {
			
			 String query = "SELECT * FROM leaves WHERE leave_id = '" + lev.getLeave_id() + "'";

		        Statement sta = DBUtil.getConnection().createStatement();
		        ResultSet rs = sta.executeQuery(query);

		        if (rs.next()) {


		            lev.setLeave_id(rs.getInt("leave_id"));
		            lev.setEmployee_id(rs.getString("employee_id"));
		            lev.setLeave_date(rs.getDate("leave_date")); 
		            lev.setLeave_type(rs.getString("leave_type"));
			       return lev ;
		        }
		} catch (Exception e) {
           e.printStackTrace();
		}
           	return null ;
	}
	
	public void update(leaves lev) {
		
		try {
			
			String query = "UPDATE leaves SET employee_id = '"+lev.getEmployee_id()+"' , leave_date = '"+lev.getLeave_date()+"' , leave_type = '"+lev.getLeave_type()+"' WHERE  leave_id = '"+lev.getLeave_id()+"'  ";
			Statement stat = DBUtil.getConnection().createStatement();
			stat.executeUpdate(query);
			
			
		} catch (Exception e) {
           e.printStackTrace();
 		}
		
	}
	
	public void delete(leaves lev) {
		
		try {
			
			String query = "DELETE  FROM leaves WHERE leave_id = '"+lev.getLeave_id()+"'";
			Statement sta = DBUtil.getConnection().createStatement();
			sta.executeUpdate(query);
			
		} catch (Exception e) {
            e.printStackTrace();		}
		
	}
	
	
}



