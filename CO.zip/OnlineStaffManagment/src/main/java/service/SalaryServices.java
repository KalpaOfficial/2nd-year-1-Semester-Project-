package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;

import model.Salary;
import util.DBUtil;



public class SalaryServices {
	
	public ArrayList<Salary> SalaryView(String employee_id, int month, int year) {
		
		ArrayList<Salary> list = new ArrayList<Salary>();
		
		try{
			
			String query = "SELECT * FROM salary WHERE employee_id = ? AND salary_month = ? AND salary_year = ?";
		
			Connection conn=DBUtil.getConnection();
			
			PreparedStatement pstmt=conn.prepareStatement(query);
			
			pstmt.setString(1,employee_id);
			pstmt.setInt(2,month);
			pstmt.setInt(3,year);

			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				Salary salary = new Salary();
				
				salary.setId(rs.getInt("id"));
				salary.setEmployee_id(rs.getString("employee_id")); 
				salary.setSalary_month(rs.getInt("salary_month"));
				salary.setSalary_year(rs.getInt("salary_year")); 
				salary.setPay_rate(rs.getDouble("pay_rate"));
				salary.setTotal_leaves(rs.getInt("total_leaves")); 
				salary.setFixed_workin_days(rs.getInt("fixed_working_days"));
				salary.setUnpaid_leaves(rs.getInt("unpaid_leaves"));
				salary.setPaid_days(rs.getInt("paid_days"));
				salary.setTotal_salary(rs.getDouble("total_salary"));
				
				double loss = salary.removedSalary(salary.getPay_rate(), salary.getUnpaid_leaves());
				salary.setLoss(loss);
				System.out.println(salary.getLoss());
				list.add(salary);
				
			}
		
		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Integrity Constraint Violation! " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
		
	}

}
