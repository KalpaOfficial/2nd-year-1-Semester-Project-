package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Complaint;
import util.DBUtil;





public class ComplaintServices {
	
	//view all complain from the DataBase
	public ArrayList<Complaint> ComplaintView(String employee_id){
		
		ArrayList<Complaint> list =  new ArrayList<Complaint>();
		
		try{
			
			String query = "SELECT * FROM complaint WHERE employee_id = '"+ employee_id +"'";
		
			Statement stmt = DBUtil.getConnection().createStatement();
			
			ResultSet rs = stmt.executeQuery(query);
			
			while(rs.next()) {
				
				Complaint complaint = new Complaint();
				
				int complaint_id = rs.getInt(1);
				String message = rs.getString(2);

				complaint.setComplaint_id(complaint_id);
				complaint.setMessage(message);
				complaint.setEmployee_id(employee_id);
				
				list.add(complaint);
				
			}
		
		return list;
	
		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Integrity Constraint Violation! " + e.getMessage());
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
	}
	
	
	//add a new complain to DB
	public void ComplaintAdd(Complaint complaint) {
		
		try {
			
			String query = "INSERT INTO complaint(employee_id,message) "
					+ "VALUES(?, ?)";
			
			Connection conn=DBUtil.getConnection();
			
			PreparedStatement pstmt=conn.prepareStatement(query);
			
			pstmt.setString(1,complaint.getEmployee_id());
			pstmt.setString(2,complaint.getMessage());

			pstmt.executeUpdate();

			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
	
	}
	
	
	public boolean ComplaintDelete(Complaint complaint) {
	    Connection conn = null;
	    PreparedStatement pstmt = null;
	    boolean isDeleted = false;
	    
	    try {
	        String query = "DELETE FROM complaint WHERE complaint_id = ?";
	        conn = DBUtil.getConnection();
	        pstmt = conn.prepareStatement(query);
	        pstmt.setInt(1, complaint.getComplaint_id());
	        
	        int rowsAffected = pstmt.executeUpdate();
	        isDeleted = rowsAffected > 0;
	        
	    } catch (SQLIntegrityConstraintViolationException e) {
	        System.err.println("Constraint Violation: " + e.getMessage());
	    } catch (SQLSyntaxErrorException e) {
	        System.err.println("Syntax Error: " + e.getMessage());
	    } catch (SQLException e) {
	        System.err.println("Database Error: " + e.getMessage());
	    } catch (Exception e) {
	        System.err.println("Unexpected Error: " + e.getMessage());
	        e.printStackTrace();
	    } finally {
	        // Close resources in reverse order of creation
	        try {
	            if (pstmt != null) pstmt.close();
	        } catch (SQLException e) {
	            System.err.println("Error closing PreparedStatement: " + e.getMessage());
	        }
	        try {
	            if (conn != null) conn.close();
	        } catch (SQLException e) {
	            System.err.println("Error closing Connection: " + e.getMessage());
	        }
	    }
	    
	    return isDeleted;
	}
	
	
	public void ComplaintUpdate(Complaint complaint) {
		
		try{
			
			String query = "UPDATE complaint SET message = ?, employee_id = ? WHERE complaint_id = ?";

			PreparedStatement pstmt = DBUtil.getConnection().prepareStatement(query);
			
			pstmt.setString(1, complaint.getMessage());
			pstmt.setString(2, complaint.getEmployee_id());
			pstmt.setInt(3, complaint.getComplaint_id());
			

			pstmt.executeUpdate();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	

}
