package service;

import model.Shift;
import util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ShiftService {
    // Create a new shift assignment
    public boolean assignShift(Shift shift) {
        String sql = "INSERT INTO assign_shift (employee_id, shift_date, shift_start, shift_end) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, shift.getEmployeeId());
            stmt.setDate(2, shift.getShiftDate());
            stmt.setTime(3, shift.getShiftStart());
            stmt.setTime(4, shift.getShiftEnd());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Get all shifts
    public List<Shift> getAllShifts() {
        List<Shift> shifts = new ArrayList<>();
        String sql = "SELECT * FROM assign_shift";
        
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Shift shift = new Shift();
                shift.setId(rs.getInt("id"));
                shift.setEmployeeId(rs.getString("employee_id"));
                shift.setShiftDate(rs.getDate("shift_date"));
                shift.setShiftStart(rs.getTime("shift_start"));
                shift.setShiftEnd(rs.getTime("shift_end"));
                shifts.add(shift);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return shifts;
    }

    // Get shifts by employee ID
    public List<Shift> getShiftsByEmployeeId(String employeeId) {
        List<Shift> shifts = new ArrayList<>();
        String sql = "SELECT * FROM assign_shift WHERE employee_id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, employeeId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Shift shift = new Shift();
                shift.setId(rs.getInt("id"));
                shift.setEmployeeId(rs.getString("employee_id"));
                shift.setShiftDate(rs.getDate("shift_date"));
                shift.setShiftStart(rs.getTime("shift_start"));
                shift.setShiftEnd(rs.getTime("shift_end"));
                shifts.add(shift);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return shifts;
    }

    // Update a shift
    public boolean updateShift(Shift shift) {
        String sql = "UPDATE assign_shift SET employee_id = ?, shift_date = ?, shift_start = ?, shift_end = ? WHERE id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, shift.getEmployeeId());
            stmt.setDate(2, shift.getShiftDate());
            stmt.setTime(3, shift.getShiftStart());
            stmt.setTime(4, shift.getShiftEnd());
            stmt.setInt(5, shift.getId());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete a shift
    public boolean deleteShift(int shiftId) {
        String sql = "DELETE FROM assign_shift WHERE id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, shiftId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}