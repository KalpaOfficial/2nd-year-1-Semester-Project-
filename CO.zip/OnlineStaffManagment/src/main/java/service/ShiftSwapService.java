// service/ShiftSwapService.java
package service;

import model.ShiftSwapRequest;
import util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ShiftSwapService {
    public boolean createRequest(ShiftSwapRequest request) {
        String sql = "INSERT INTO shift_swap_requests (employee_id, shift_date, shift_start, shift_end, reason) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, request.getEmployeeId());
            stmt.setDate(2, request.getShiftDate());
            stmt.setTime(3, request.getShiftStart());
            stmt.setTime(4, request.getShiftEnd());
            stmt.setString(5, request.getReason());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<ShiftSwapRequest> getAllPendingRequests() {
        List<ShiftSwapRequest> requests = new ArrayList<>();
        String sql = "SELECT * FROM shift_swap_requests WHERE status = 'pending'";
        
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                ShiftSwapRequest request = new ShiftSwapRequest();
                request.setId(rs.getInt("id"));
                request.setEmployeeId(rs.getString("employee_id"));
                request.setShiftDate(rs.getDate("shift_date"));
                request.setShiftStart(rs.getTime("shift_start"));
                request.setShiftEnd(rs.getTime("shift_end"));
                request.setReason(rs.getString("reason"));
                request.setStatus(rs.getString("status"));
                requests.add(request);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return requests;
    }

    public boolean approveRequest(int requestId) {
        Connection conn = null;
        try {
            conn = DBUtil.getConnection();
            conn.setAutoCommit(false);
            
            // 1. Get the request details using the new method
            ShiftSwapRequest request = getRequestById(requestId);
            if (request == null) return false;
            
            // Rest of the method remains the same...
            String deleteSql = "DELETE FROM assign_shift WHERE employee_id = ? AND shift_date = ? AND shift_start = ? AND shift_end = ?";
            try (PreparedStatement stmt = conn.prepareStatement(deleteSql)) {
                stmt.setString(1, request.getEmployeeId());
                stmt.setDate(2, request.getShiftDate());
                stmt.setTime(3, request.getShiftStart());
                stmt.setTime(4, request.getShiftEnd());
                
                int deleted = stmt.executeUpdate();
                if (deleted == 0) {
                    conn.rollback();
                    return false;
                }
            }
            
            String updateSql = "UPDATE shift_swap_requests SET status = 'approved' WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(updateSql)) {
                stmt.setInt(1, requestId);
                int updated = stmt.executeUpdate();
                
                if (updated == 1) {
                    conn.commit();
                    return true;
                } else {
                    conn.rollback();
                    return false;
                }
            }
        } catch (SQLException e) {
            try { if (conn != null) conn.rollback(); } catch (SQLException ex) {}
            e.printStackTrace();
            return false;
        } finally {
            try { if (conn != null) conn.setAutoCommit(true); } catch (SQLException e) {}
        }
    }

    public boolean rejectRequest(int requestId) {
        String sql = "UPDATE shift_swap_requests SET status = 'rejected' WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, requestId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public ShiftSwapRequest getRequestById(int requestId) {
        String sql = "SELECT * FROM shift_swap_requests WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, requestId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                ShiftSwapRequest request = new ShiftSwapRequest();
                request.setId(rs.getInt("id"));
                request.setEmployeeId(rs.getString("employee_id"));
                request.setShiftDate(rs.getDate("shift_date"));
                request.setShiftStart(rs.getTime("shift_start"));
                request.setShiftEnd(rs.getTime("shift_end"));
                request.setReason(rs.getString("reason"));
                request.setStatus(rs.getString("status"));
                return request;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    
    }
}