// model/Shift.java
package model;

import java.sql.Time;
import java.sql.Date;

public class Shift {
    private int id;
    private String employeeId;
    private Date shiftDate;
    private Time shiftStart;
    private Time shiftEnd;

    // Constructors
    public Shift() {}
    
    public Shift(String employeeId, Date shiftDate, Time shiftStart, Time shiftEnd) {
        this.employeeId = employeeId;
        this.shiftDate = shiftDate;
        this.shiftStart = shiftStart;
        this.shiftEnd = shiftEnd;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getEmployeeId() { return employeeId; }
    public void setEmployeeId(String employeeId) { this.employeeId = employeeId; }
    public Date getShiftDate() { return shiftDate; }
    public void setShiftDate(Date shiftDate) { this.shiftDate = shiftDate; }
    public Time getShiftStart() { return shiftStart; }
    public void setShiftStart(Time shiftStart) { this.shiftStart = shiftStart; }
    public Time getShiftEnd() { return shiftEnd; }
    public void setShiftEnd(Time shiftEnd) { this.shiftEnd = shiftEnd; }
}