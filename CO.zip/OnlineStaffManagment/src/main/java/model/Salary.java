package model;

public class Salary {
	
	private int id;
	private String employee_id;
	private int salary_month;
	private int salary_year;
	private double pay_rate;
	private int fixed_workin_days;
	private int total_leaves;
	private int unpaid_leaves;
	private int paid_days;
	private double loss;

	private double total_salary;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(String employee_id) {
		this.employee_id = employee_id;
	}
	public int getSalary_month() {
		return salary_month;
	}
	public void setSalary_month(int salary_month) {
		this.salary_month = salary_month;
	}
	public int getSalary_year() {
		return salary_year;
	}
	public void setSalary_year(int salary_year) {
		this.salary_year = salary_year;
	}
	public double getPay_rate() {
		return pay_rate;
	}
	public void setPay_rate(double pay_rate) {
		this.pay_rate = pay_rate;
	}
	public int getFixed_workin_days() {
		return fixed_workin_days;
	}
	public void setFixed_workin_days(int fixed_workin_days) {
		this.fixed_workin_days = fixed_workin_days;
	}
	public int getTotal_leaves() {
		return total_leaves;
	}
	public void setTotal_leaves(int total_leaves) {
		this.total_leaves = total_leaves;
	}
	public int getUnpaid_leaves() {
		return unpaid_leaves;
	}
	public void setUnpaid_leaves(int unpaid_leaves) {
		this.unpaid_leaves = unpaid_leaves;
	}
	public int getPaid_days() {
		return paid_days;
	}
	public void setPaid_days(int paid_days) {
		this.paid_days = paid_days;
	}
	public double getTotal_salary() {
		return total_salary;
	}
	public void setTotal_salary(double total_salary) {
		this.total_salary = total_salary;
	}
	
	public double getLoss() {
		return loss;
	}
	public void setLoss(double loss) {
		this.loss = loss;
	}
	
	public double removedSalary(double payRate, int unpaidLeaves) {
		
		return payRate * unpaidLeaves;
		
	}
	
}
